// Perlin noice
// Rupam Niyogi
// 10/18/2023
//
// Extra for Experts:
// - I added a flag that moves 
let rectWidth = 1;
let noiseScale = 0.02;
let noiseValue = 1;
let highesty = 100000;
let highestx = 0;
let sectionHeight;
let average;
let numrect;
let runningtotal;
let hold = noiseValue; 
function setup() {
  createCanvas(windowWidth, windowHeight);
  rectMode(CORNERS);
  generateTerrain();
}
function draw(){
  background(255);
  hold += noiseScale;
  noiseValue = hold;
  generateTerrain();
}
function generateTerrain() {
  let highesty = 100000;
  runningtotal = 0;
  numrect = width/rectWidth;
  for (let x = 0; x < width; x += rectWidth) {
    fill(0);
    let sectionHeight = noise(noiseValue) * height;
    noiseValue += noiseScale;
    rect(x, height, x + rectWidth, sectionHeight);
    runningtotal += sectionHeight;
    average = runningtotal/ numrect;
    fill("red");
    if (highesty > sectionHeight) {
      highesty = sectionHeight;
      highestx = x;
    }
  }
  stroke("red");
  line(0,average,width, average);
  stroke(0);
  drawFlag(highestx,highesty);
}
drawFlag(highestx,highesty);
function drawFlag(x,y) {
  line(x, y-30, x, y);
  fill("red");
  triangle(x, y-20,x,y-30,x+10, y-25);
  fill(0);
}
function keyPressed() {
  if (keyCode === 37) {
    rectWidth += 0.05;
  }
  if (keyCode === 39) {
    rectWidth -= 0.05;
  }
  background(255);
  generateTerrain();
  drawFlag();
}